//
//  ViewController.swift
//  Areti_FormatName
//
//  Created by Areti,Vamsi Krishna on 2/02/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var detailsHeadingLabel: UILabel!
    @IBOutlet weak var initLabel: UILabel!
    @IBOutlet weak var fNameLabel: UILabel!
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var fullNameLabel: UILabel!
    @IBOutlet weak var initialsLabel: UILabel!
    @IBOutlet weak var lastNameTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        hideTheLabels()
    }
    
    func hideTheLabels(){
        detailsHeadingLabel.isHidden = true
        fNameLabel.isHidden = true
        initLabel.isHidden = true
    }

    func showTheLabels(){
        detailsHeadingLabel.isHidden = false
        fNameLabel.isHidden = false
        initLabel.isHidden = false
        let firstName = firstNameTextField.text!
        let lastName = lastNameTextField.text!
        fullNameLabel.text = "\(firstName), \(lastName)"
        let firstInitial = firstName.prefix(1)
        let lastInitial = lastName.prefix(1)
        initialsLabel.text = "\(firstInitial)\(lastInitial)"
    }
    
    func resetTheLabels(){
        firstNameTextField.text = ""
        lastNameTextField.text = ""
        fullNameLabel.text = ""
        initialsLabel.text = ""
    }

    @IBAction func onClickOfSubmit(_ sender: UIButton) {
        showTheLabels()
    }

    
    @IBAction func onClickOfReset(_ sender: UIButton) {
        hideTheLabels()
        resetTheLabels()
        firstNameTextField.becomeFirstResponder()
    }
    
}



